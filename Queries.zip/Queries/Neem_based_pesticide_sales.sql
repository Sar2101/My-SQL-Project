CREATE TABLE Neem_based_pesticide_sales (
    STATE VARCHAR(40),
    Yr_2007_2008 FLOAT,
    Yr_2008_2009 FLOAT,
    Yr_2009_2010 FLOAT,
    Yr_2010_2011 FLOAT,
    Yr_2011_2012 FLOAT,
    Yr_2012_2013 FLOAT,
    Yr_2013_2014 FLOAT,
    Yr_2014_2015 FLOAT,
    Yr_2015_2016 FLOAT,
    Yr_2016_2017 FLOAT,
    Yr_2017_2018 FLOAT,
    Yr_2018_2019 FLOAT,
    Yr_2019_2020 FLOAT,
    Yr_2020_2021 FLOAT,
    Yr_2021_2022 FLOAT,
    Yr_2022_2023 FLOAT
);
desc Neem_based_pesticide_sales;
insert into Neem_based_pesticide_sales values('TAMIL NADU','34.48','53.06','56.19','54.29','65.04','57.19','74.66','74.01','83.71','66.08','93.45','99.37','144.00','192.61','260.75','505.05');
insert into Neem_based_pesticide_sales values('PONDICHERRY','2.06','2.42','4.26','2.61','1.50','1.47','2.68','3.63','3.22','3.19','3.83','2.27','2.74','5.11','7.67','8.49');
insert into Neem_based_pesticide_sales values('ANDHRA/TG','41.86','43.35','38.99','44.63','57.00','53.00','64.65','67.18','44.25','53.91','51.97','70.18','57.67','73.40','50.99','82.44');
insert into Neem_based_pesticide_sales values('KARNATAKA','32.84','35.36','43.41','37.41','53.41','32.61','49.43','46.12','4.62','33.21','16.78','30.82','29.59','57.45','17.49','96.91');
insert into Neem_based_pesticide_sales values('KERALA','1.73','1.90','1.83','3.06','4.15','2.17','3.91','6.43','16.63','19.15','12.67','13.45','11.50','8.82','76.10','21.95');
insert into Neem_based_pesticide_sales values('TOTAL','112.97','136.09','144.68','142.00','181.10','146.44','195.33','197.37','152.43','175.54','178.70','216.09','245.50','337.39','413.00','714.84');
select * from Neem_based_pesticide_sales;
alter table Neem_based_pesticide_sales add primary key(STATE);