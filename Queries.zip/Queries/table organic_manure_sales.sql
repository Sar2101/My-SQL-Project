CREATE TABLE organic_manure_sales (
    STATE VARCHAR(40),
    Year_2011_2012 FLOAT,
    Year_2012_2013 FLOAT,
    Year_2013_2014 FLOAT,
    Year_2014_2015 FLOAT,
    Year_2015_2016 FLOAT,
    Year_2016_2017 FLOAT,
    Year_2017_2018 FLOAT,
    Year_2018_2019 FLOAT,
    Year_2019_2020 FLOAT,
    Year_2020_2021 FLOAT,
    Year_2021_2022 FLOAT,
    Year_2022_2023 FLOAT
);
desc organic_manure_sales;
insert into organic_manure_sales values('TAMIL NADU','1780','1359','3732','3100','3932','232','189','216','1208','2697','4650','4550');
insert into organic_manure_sales values('PONDICHERRY','86','72','188','170','142','0','0','0','20','0','155','120');
insert into organic_manure_sales values('ANDHRA/TG','0','0','536','660','1142','0','506','0','50','25','200','747');
insert into organic_manure_sales values('KARNATAKA','1764','2356','4078','1143','2341','240','400','49','787','836','1125','970');
insert into organic_manure_sales values('KERALA','0','40','364','360','690','240','589','640','743','1488','702','1449');
insert into organic_manure_sales values('TOTAL','3630','3827','8898','5433','8247','712','1684','905','2808','5046','6832','7836');
select * from organic_manure_sales;
alter table organic_manure_sales add foreign key (STATE) references Neem_based_pesticide_sales(STATE);