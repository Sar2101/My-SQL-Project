create table city_compost_sales(STATE varchar(40),Year_16_17 float,Year_17_18 float,Year_18_19 float,Year_19_20 float,Year_20_21 float,Year_21_22 float,Year_22_23 float);
desc city_compost_sales;
insert into city_compost_sales values('TAMIL NADU','1284','6084','3834','4686','3167','6365','4999');
insert into city_compost_sales values('PONDICHERRY','40','203','212','115','90','102','200');
insert into city_compost_sales values('ANDHRA/TG','148','957','1662','1695','1298','390','1086');
insert into city_compost_sales values('KARNATAKA','219','1185','1944','3566','1696','1697','2513');
insert into city_compost_sales values('KERALA','15','191','435','1979','152','2080','810');
insert into city_compost_sales values('TOTAL','1706','8620','8087','12041','6403','10634','9608');
SELECT 
    *
FROM
    city_compost_sales;
alter table city_compost_sales add foreign key (STATE) references Neem_based_pesticide_sales(STATE);