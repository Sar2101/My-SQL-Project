show databases;
use sqlproject;
show tables;
select * from avg_sales_of_urea;
insert into avg_sales_of_urea values ('TAMILNADU','TOTAL','211152.15','171176.80','224091.85','136938.25','196605.75','205621.00','244437.40','221881.130','162095.895','260997.975','292147.605','306178.920','219444','0');
insert into avg_sales_of_urea values ('PONDICHERRY','KARAIKKAL','17381.00','10681.00','17348.80','9601.00','8226.00','7139.00','8498.00','8054.555','6469.875','11267.640','10665.225','11830.050','10597','2');
insert into avg_sales_of_urea values ('TELENGANA','HYDREBAD','52937.60','30351.55','39187.65','24557.80','23538.70','26492.15','33538.35','30968.713','23956.965','34687.170','17446.545','16352.910','29501','7');
insert into avg_sales_of_urea values ('ANDHRA PRADESH','KADAPA','28005.45','30283.00','35790.30','18986.10','16937.10','25560.55','223675.65','29574.730','26103.330','29273.310','26060.085','27893.340','26512','6');
insert into avg_sales_of_urea values ('ANDHRA PRADESH','TOTAL_A','69980.85','78454.15','73034.70','43208.70','42401.05','64181.15','54451.45','69191.410','53085.600','59618.475','49220.280','51056.550','58991','0');
insert into avg_sales_of_urea values ('KARNATAKA','BANGLORE','33968.60','31268.27','30592.50','29381.60','26698.05','28705.30','36194.85','33434.050','18712.080','34426.305','37210.275','35319.645','31321','7');
insert into avg_sales_of_urea values ('KARNATAKA','DEVANGERE','45155.65','34805.60','37858.40','27241.30','14470.35','37548.80','39401.75','23469.180','22096.620','30039.750','36237.240','47461.365','32982','8');
insert into avg_sales_of_urea values ('KARNATAKA','BELLARY','51097.50','48008.15','43061.20','33383.10','19422.50','28241.10','30541.30','19193.215','24138.900','24307.200','35328.600','32594.400','32443','7');
insert into avg_sales_of_urea values ('KARNATAKA','TOTAL_KA','130221.75','114082.02','111449.10','90006.00','60590.90','94495.20','106137.90','76096.445','64947.600','88773.255','108776.115','115375.410','96476','0');
insert into avg_sales_of_urea values ('KERALA','COCHIN','17004.90','19253.60','34484.45','21587.35','23360.75','36602.25','25475.40','13573.930','13208.265','23307.840','26303.580','29085.570','23604','6');
insert into avg_sales_of_urea values ('A&N','MHO','840.00','500.00','500.00','600.00','400.00','1000.00','500.00','0.000','0.000','749.970','0.000','0.000','424','0');
insert into avg_sales_of_urea values ('ALL_STATES','TOTAL','499518.25','42499.12','500096.55','326499.10','355123.15','4355398.75','473038','419766.183','323764.200','479402.325','504559.350','529879.410','439307','100');
select * from avg_sales_of_urea;
set sql_safe_updates=0;
update avg_sales_of_urea set average_percentage ='3'where Regional_office='MHO' and STATE='A&N';
select max(average_percentage) as max_percentage from avg_sales_of_urea;
select min(average_percentage) as min_percentage from avg_sales_of_urea;
select max(average_percentage) from avg_sales_of_urea;
SELECT 
    MAX(average_percentage) as 3rd_Max_avg
FROM
    avg_sales_of_urea
WHERE
    average_percentage < (SELECT 
            MAX(average_percentage)
        FROM
            avg_sales_of_urea
        WHERE
            average_percentage < (SELECT 
                    MAX(average_percentage)
                FROM
                    avg_sales_of_urea));
    select  STATE,REGIONAL_OFFICE,Average_Sales_in_MT from avg_sales_of_urea where Average_Sales_in_MT between 50000 and 100000;
    select STATE,REGIONAL_OFFICE,Average_Sales_in_MT from avg_sales_of_urea where Average_Sales_in_MT > 100000;
    
    select distinct substr(STATE,1,2) as FIRST_2_LETTERS from avg_sales_of_urea ;
    select STATE,REGIONAL_OFFICE,Average_Sales_in_MT from avg_sales_of_urea where STATE like '%A'
    