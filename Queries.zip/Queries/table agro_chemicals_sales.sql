CREATE TABLE agro_chemicals_sales (
    STATE VARCHAR(40),
    Yr_2011_2012 FLOAT,
    Yr_2012_2013 FLOAT,
    Yr_2013_2014 FLOAT,
    Yr_2014_2015 FLOAT,
    Yr_2015_2016 FLOAT,
    Yr_2016_2017 FLOAT,
    Yr_2017_2018 FLOAT,
    Yr_2018_2019 FLOAT,
    Yr_2019_2020 FLOAT,
    Yr_2020_2021 FLOAT,
    Yr_2021_2022 FLOAT,
    Yr_2022_2023 FLOAT
);
desc agro_chemicals_sales;
insert into agro_chemicals_sales values('TAMIL NADU','42.18','343.16','42.93','40.99','38.47','30.46','31.43','35.34','43.30','56.34','72.12','113.38');
insert into agro_chemicals_sales values('PONDICHERRY','1.00','0.95','2.00','2.00','2.00','1.50','1.34','0.81','0.83','2.00','2.01','1.84');
insert into agro_chemicals_sales values('ANDHRA/TG','38.09','34.16','38.97','39.77','20.32','23.64','17.20','24.13','16.54','19.00','13.41','16.88');
insert into agro_chemicals_sales values('KARNATAKA','33.34','19.75','29.72','27.56','2.00','15.95','5.83','11.19','9.14','16.33','21.26','21.14');
insert into agro_chemicals_sales values('KERALA','2.00','1.28','2.00','3.30','7.30','9.00','4.32','5.06','3.61','3.00','4.83','4.18');
insert into agro_chemicals_sales values('TOTAL','116.61','90.30','115.62','113.62','70.09','80.55','60.12','76.53','73.42','96.67','113.63','157.42');
select * from agro_chemicals_sales;
alter table agro_chemicals_sales add foreign key (STATE) references Neem_based_pesticide_sales(STATE);
