CREATE TABLE bio_fertilizer_sales (
    STATE VARCHAR(40),
    Yr_2007_2008 FLOAT,
    Yr_2008_2009 FLOAT,
    Yr_2009_2010 FLOAT,
    Yr_2010_2011 FLOAT,
    Yr_2011_2012 FLOAT,
    Yr_2012_2013 FLOAT,
    Yr_2013_2014 FLOAT,
    Yr_2014_2015 FLOAT,
    Yr_2015_2016 FLOAT,
    Yr_2016_2017 FLOAT,
    Yr_2017_2018 FLOAT,
    Yr_2018_2019 FLOAT,
    Yr_2019_2020 FLOAT,
    Yr_2020_2021 FLOAT,
    Yr_2021_2022 FLOAT,
    Yr_2022_2023 FLOAT
);
desc bio_fertilizer_sales;
insert into bio_fertilizer_sales values ('TAMIL NADU','172','211','198','200','182','164','84','197','140','70','54','103','14','119','95','0');
insert into bio_fertilizer_sales values ('PONDICHERRY','6','6','8','8','6','5','1','3','2','1','0','3','0','3','0','0');
insert into bio_fertilizer_sales values ('ANDHRA/TG','64','87','75','98','101','103','52','65','41','20','27','32','28','23','20','8');
insert into bio_fertilizer_sales values ('KARNATAKA','135','148','143','140','184','100','9','78','84','19','2','11','3','9','51','14');
insert into bio_fertilizer_sales values ('KERALA','9','11','11','7','8','5','1','6','10','1','0','1','1','3','2','0');
insert into bio_fertilizer_sales values ('TOTAL','386','463','435','453','481','377','147','349','277','111','83','150','46','157','169','23');
select * from bio_fertilizer_sales;
alter table bio_fertilizer_sales add foreign key (STATE) references Neem_based_pesticide_sales(STATE);