SELECT 
    Neem_based_pesticide_sales.STATE,
    Neem_based_pesticide_sales.Yr_2022_2023 AS Neem_pesticides,
    agro_chemicals_sales.Yr_2022_2023 AS Agro_chemicals,
    bio_fertilizer_sales.Yr_2022_2023 AS Bio_Fertilizers,
    organic_manure_sales.Year_2022_2023 AS Organic_manure,
    city_compost_sales.Year_22_23 AS City_compost
FROM
    Neem_based_pesticide_sales
        JOIN
    agro_chemicals_sales ON Neem_based_pesticide_sales.STATE = agro_chemicals_sales.STATE
        JOIN
    bio_fertilizer_sales ON agro_chemicals_sales.STATE = bio_fertilizer_sales.STATE
        JOIN
    organic_manure_sales ON bio_fertilizer_sales.STATE = organic_manure_sales.STATE
        JOIN
    city_compost_sales ON organic_manure_sales.STATE = city_compost_sales.STATE;